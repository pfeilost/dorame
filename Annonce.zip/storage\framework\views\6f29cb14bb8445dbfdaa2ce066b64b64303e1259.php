<button type="submit" class="btn btn-primary float-right">
    <?php echo e($slot); ?>

</button>