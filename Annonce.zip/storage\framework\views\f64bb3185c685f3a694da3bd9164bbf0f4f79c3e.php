<div class="card text-white bg-dark mb-3">
    <h4 class="card-header">
        <?php echo e($title); ?>

    </h4>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
</div>